"""
Token management system for EmpireBox
Routes requests to local or cloud based on complexity + budget
"""

class TokenManager:
    def __init__(self, user_tier: str, monthly_budget: int):
        self.tier = user_tier
        self.monthly_budget = monthly_budget  # tokens
        self.tokens_used = 0
        
        # Tier limits
        self.limits = {
            "free": 500_000,
            "lite": 2_000_000,
            "pro": 5_000_000,
            "empire": 15_000_000
        }
    
    def route_request(self, task_type: str, complexity: str):
        """
        Decide: local (Ollama) or cloud (Grok/Claude)?
        """
        # Simple tasks → Local (free)
        local_tasks = [
            "format_text",
            "categorize_product", 
            "fill_template",
            "extract_fields",
            "simple_validation"
        ]
        
        if task_type in local_tasks and complexity == "low":
            return "ollama", "phi-3-mini"
        
        # Complex tasks → Cloud (paid)
        if self.tokens_used < self.limits[self.tier]:
            return "grok", "grok-2-fast"
        else:
            # Over budget - fallback to local or queue
            return "ollama", "llama-3.2-3b"  # Slower but free
    
    def track_usage(self, tokens: int):
        self.tokens_used += tokens
        
        # Alert if approaching limit
        if self.tokens_used > self.limits[self.tier] * 0.8:
            self.send_usage_warning()
    
    def send_usage_warning(self):
        # Notify user they're at 80% of monthly budget
        pass