# Key features:
# - Rate limiting (actions per minute)
# - Budget tracking (total actions allowed)
# - Action whitelist (only permitted actions execute)
# - Thread-safe with locks
# - Emergency stop capability