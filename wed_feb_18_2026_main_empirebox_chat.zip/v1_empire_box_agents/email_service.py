"""
MarketForge Email Alias Service
Creates and manages user@marketforge.app addresses
"""

import requests
from typing import Optional

class EmailAliasService:
    """
    Uses Cloudflare Email Routing or similar service
    to create email aliases that forward to user's inbox
    """
    
    def __init__(self, api_key: str, domain: str = "marketforge.app"):
        self.api_key = api_key
        self.domain = domain
        self.base_url = "https://api.cloudflare.com/client/v4"
    
    def create_alias(self, username: str, forward_to: str) -> dict:
        """
        Create username@marketforge.app that forwards to user's email
        """
        alias = f"{username}@{self.domain}"
        
        # Cloudflare Email Routing API call
        response = requests.post(
            f"{self.base_url}/zones/{self.zone_id}/email/routing/rules",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "name": f"MarketForge user: {username}",
                "enabled": True,
                "matchers": [{"type": "literal", "field": "to", "value": alias}],
                "actions": [{"type": "forward", "value": [forward_to]}]
            }
        )
        
        return {
            "alias": alias,
            "forwards_to": forward_to,
            "status": "active"
        }
    
    def list_user_emails(self, user_id: str) -> list:
        """
        Get all emails received by this user's alias
        (Retrieved from our database, not Cloudflare)
        """
        # Query our message store
        pass
    
    def get_inbox(self, user_id: str, limit: int = 50) -> list:
        """
        Get unified inbox - emails + marketplace messages
        """
        emails = self.list_user_emails(user_id)
        ebay_messages = self.get_ebay_messages(user_id)
        fb_messages = self.get_fb_messages(user_id)
        
        # Merge and sort by timestamp
        all_messages = emails + ebay_messages + fb_messages
        all_messages.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return all_messages[:limit]