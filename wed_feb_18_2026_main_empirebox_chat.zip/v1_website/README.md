# EmpireBox Website

Complete marketing website for EmpireBox - The Operating System for Resellers, including all Stripe-compliant legal pages required for merchant account approval.

## Overview

This directory contains:

1. **Static HTML** (`/static`) - Single-file HTML version for reference
2. **Next.js** (`/nextjs`) - Production-ready modern web application
3. **Documentation** (`/docs`) - Complete website documentation and guides

## Project Structure
