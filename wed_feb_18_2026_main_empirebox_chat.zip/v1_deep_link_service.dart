import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:uni_links/uni_links.dart';

class DeepLinkService {
  static Future<void> init() async {
    // Skip deep links on web - not supported
    if (kIsWeb) {
      return;
    }
    
    try {
      // Only run on mobile platforms
      linkStream.listen((String? link) {
        if (link != null) {
          _handleDeepLink(link);
        }
      });
    } catch (e) {
      // Deep links not supported on this platform
      print('Deep links not available: $e');
    }
  }

  static void _handleDeepLink(String link) {
    // Handle deep link logic here
    print('Received deep link: $link');
  }
}