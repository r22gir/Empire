import 'package:flutter/material.dart';
import '../models/message.dart';

class MessagesScreen extends StatefulWidget {
  @override
  _MessagesScreenState createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  MessageSource? _filterSource;
  bool _aiAssistEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Messages'),
        actions: [
          // AI Assistant toggle
          IconButton(
            icon: Icon(_aiAssistEnabled ? Icons.auto_awesome : Icons.auto_awesome_outlined),
            onPressed: () => setState(() => _aiAssistEnabled = !_aiAssistEnabled),
            tooltip: 'AI Draft Responses',
          ),
          // Filter dropdown
          PopupMenuButton<MessageSource?>(
            icon: Icon(Icons.filter_list),
            onSelected: (source) => setState(() => _filterSource = source),
            itemBuilder: (context) => [
              PopupMenuItem(value: null, child: Text('All Sources')),
              PopupMenuItem(value: MessageSource.email, child: Text('📧 Email')),
              PopupMenuItem(value: MessageSource.ebay, child: Text('🛒 eBay')),
              PopupMenuItem(value: MessageSource.facebook, child: Text('📘 Facebook')),
            ],
          ),
        ],
      ),
      body: _buildMessageList(),
    );
  }

  Widget _buildMessageList() {
    // TODO: Get from provider
    return ListView.builder(
      itemCount: 10,
      itemBuilder: (context, index) => _buildMessageTile(index),
    );
  }

  Widget _buildMessageTile(int index) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        leading: _getSourceIcon(MessageSource.ebay),
        title: Text('Buyer Name'),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Is this still available?', maxLines: 1, overflow: TextOverflow.ellipsis),
            if (_aiAssistEnabled)
              Container(
                margin: EdgeInsets.only(top: 4),
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.auto_awesome, size: 16, color: Colors.purple),
                    SizedBox(width: 4),
                    Expanded(child: Text('AI: "Yes! Ready to ship today."', style: TextStyle(fontSize: 12))),
                  ],
                ),
              ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('2m', style: TextStyle(fontSize: 12, color: Colors.grey)),
            SizedBox(height: 4),
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(color: Colors.blue, shape: BoxShape.circle),
            ),
          ],
        ),
        onTap: () => _openMessage(index),
      ),
    );
  }

  Widget _getSourceIcon(MessageSource source) {
    switch (source) {
      case MessageSource.email: return CircleAvatar(child: Text('📧'));
      case MessageSource.ebay: return CircleAvatar(backgroundColor: Colors.yellow[700], child: Text('e', style: TextStyle(fontWeight: FontWeight.bold)));
      case MessageSource.facebook: return CircleAvatar(backgroundColor: Colors.blue, child: Icon(Icons.facebook, color: Colors.white));
      default: return CircleAvatar(child: Icon(Icons.message));
    }
  }

  void _openMessage(int index) {
    // Navigate to message detail
  }
}