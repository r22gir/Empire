/// Unified message model for all communication channels
class Message {
  final String id;
  final MessageSource source; // email, ebay, facebook, craigslist
  final String senderName;
  final String senderEmail;
  final String subject;
  final String body;
  final String? listingId; // Link to product if applicable
  final DateTime timestamp;
  final bool isRead;
  final String? aiDraftResponse;

  Message({
    required this.id,
    required this.source,
    required this.senderName,
    required this.senderEmail,
    required this.subject,
    required this.body,
    this.listingId,
    required this.timestamp,
    this.isRead = false,
    this.aiDraftResponse,
  });
}

enum MessageSource {
  email,
  ebay,
  facebook,
  craigslist,
  mercari,
  etsy,
  amazon,
}